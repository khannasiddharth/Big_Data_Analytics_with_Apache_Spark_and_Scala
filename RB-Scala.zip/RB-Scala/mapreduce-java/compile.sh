#!/bin/bash

javac -classpath /usr/lib/hadoop/hadoop-common.jar:/usr/lib/hadoop/client/h\
adoop-mapreduce-client-core.jar  exercise.java

# creates exercise.jar file : zip up all the class file that u get into a jar file using this command.
jar cvf exercise.jar exercise*.class
