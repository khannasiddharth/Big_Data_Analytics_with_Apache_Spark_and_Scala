import java.io.* ;
import org.apache.hadoop.conf.Configuration ;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat; 

////// MAP FUNCTION //////
/*Sample Program that takes soccer players individual scores and computes total by player*/
/*
inside Java, we have two classes - one class for the mapper and the other class for the reducer.
Of course you could have written them in different files you know but just for simplicity sake I just
picked up this one file here.

The first class you see here is the class - It has just two classes 
Class exercise - Inside this is a public static class SoccerScoreMapper which extends regular Mapper class
*/
public class exercise 
{
   
    public static class SoccerScoreMapper
    extends Mapper<Object, Text, Text, IntWritable>
{
       //Use map reduce specific data types 
	   /*
		That is a part of the Hadoop Java distribution. It is a standard class that every mapper program has to extend.
		So this is the rule you have to follow. And then inside there are two variables defined -

		score is integre which is IntWritable form - IntWritable means is that it's a data type that is given to you by 
		Hadoop and you have to use data if you are outputting key value pairs, u have to be using these data types
		not the regular Java data types. So IntWritable is used for integers. 
		And that is another data type called Text that are used for text.
		*/

        private final static IntWritable score = new IntWritable(1);
        private Text player = new Text();
        
		/*
		Then here comes the map program. This is a standard definition of how map program will look like - 
		basically overriding the map function in the base class.That's map function.
		And the main thing you see is Text value. Are there other things that are passed.
		you're not going to focus on them.
		The map program gets as input the text values - so every line in the file is going to come to you
		once. We saw that the input file had actually six lines. So this map function is going to be called 
		once every line. Then what MapReduce program does it with the line depends on your own specific situation.
		*/
        public void map(Object key, Text value, Context context
        ) throws IOException, InterruptedException {
	   //Read each line and split as player name and score - splitting by "," to get keyvalues
            String[] keyvalues = value.toString().split(",") ;

		// iterate over each of the keyvalues
	    for ( String keyvalue : keyvalues ) {
			//System.out.println(keyvalue);

			// and each of keyvalues coming out u again split by "=" sign, so u can get Key & Value
			String[] valueArray= keyvalue.split("=");

			// ignore values if Key is "Game", "Date" OR "Goals"
			if ( ( ! valueArray[0].equals("Game")) && 
				(! valueArray[0].equals("Date")) && 
				(! valueArray[0].equals("Goals")) ) {

				// name of Player is set to player (Key)
				player.set(valueArray[0]);
				// score of Player is set to value
				score.set(Integer.valueOf(valueArray[1]));
				// output keyvalue (namevalue) pair
				context.write(player,score);
			}	
	    }
	    
        }
    }

////// REDUCE FUNCTION //////
public static class SoccerScoreReducer
	// extends Base class called Reducer which comes as part of HDFS. Here we have function reduce which u have to override
	// reduce function gets as input a Text key (key as Text) and Iterable<IntWritable> values - so we have Keys and Values
	// and a Context. We will find total of the values
    extends Reducer<Text,IntWritable,Text,IntWritable> {
        public void reduce(Text key, Iterable<IntWritable> values,
            Context context
            ) throws IOException, InterruptedException {
				// intialise variable total
                int total = 0;
				// iterate over individual values and as values come up keep adding them to total
            for (IntWritable score : values) {
                total = total+score.get() ;
            }
			// finally u have iterated over all values and found total score for players - Key is player and total is total score for player 
			// it basically summarises the total score by player. For e.g. for Ben it sums scores 2,1,1 -> key = Ben, value = Total = 4
            context.write(key, new IntWritable(total));
        }
    }
    
	// Job configuration - create Configuration & Job objects and do few settings. For e.g. setJarByClass is exercise.class
	// set Mapper - SoccerScoreMapper, Reducer - SoccerScoreReducer, class of Key (setOutputKeyClass) - Text.class
	// class of value - setOutputValueClass. 
	// key is going to be text (player) & the value (score) is going to be integer.
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        Job job = new Job(conf, "Player scores");
        job.setJarByClass(exercise.class);
        job.setMapperClass(SoccerScoreMapper.class);
        job.setReducerClass(SoccerScoreReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);
		// add input and output path and for this we use cmd line argument so when I call program, I pass 
		// input dir where data is sitting as part of input path and output is again passed at cli
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
		// exit
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
