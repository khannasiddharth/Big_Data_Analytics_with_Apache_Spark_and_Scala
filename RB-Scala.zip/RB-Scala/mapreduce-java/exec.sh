#!/bin/bash

export CLASSPATH=:./usr/lib/hadoop/hadoop-common.jar:/usr/lib/hadoop/client/h\
adoop-mapreduce-client-core.jar 

# Input data is in directory data - 
echo Input Data:
echo
hadoop fs -cat data/*

# start MapR program, bfr that delete output directory
echo
echo Starting Map Reduce :
echo
hadoop fs -rm -r output

# execute MapR program (input file is jar file and for that exercise.jar that I build is passed as a prameter and then
# next prameter is what class within exercise.jar contains the main class 'exercise' and what are the inputs to
# exercise class - 1st para is input dir (data dir) and 2nd is output dir (output) )
hadoop jar exercise.jar exercise data output

# ouptut MapR output
echo 
echo Map Reduce Complete :
echo Output is
echo

# cat of output dir - part-r-00000 
hadoop fs -cat output/part-r-00000





